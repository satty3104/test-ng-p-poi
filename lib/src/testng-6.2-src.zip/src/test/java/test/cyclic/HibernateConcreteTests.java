package test.cyclic;

import org.testng.annotations.Test;

public class HibernateConcreteTests extends AbstractGenericTests {

    @Test(groups="integration")
    public void testSomethingElse() {
        //...
    }

 }