package test.bug92;

import org.testng.annotations.Test;

public class TestAlpha extends TestBase {

	@Test
	public void test1() {
	}

	@Test
	public void test2() {
	}
}